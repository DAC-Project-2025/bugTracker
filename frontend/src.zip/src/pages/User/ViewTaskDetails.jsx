import React from 'react'

const ViewTaskDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default ViewTaskDetails
