import React from 'react'

const ManageUser = () => {
  return (
    <div>
      
    </div>
  )
}

export default ManageUser
