import {jwtDecode} from "jwt-decode";
import { Navigate, Outlet } from "react-router-dom";

const PrivateRoutes = ({ allowedRoles }) => {
  const token = localStorage.getItem("token");

  if (!token) {
    return <Navigate to="/login" />;
  }

  try {
    const decoded = jwtDecode(token);
    // decoded.authorities might be string or array
    let userRoles = decoded.authorities;

    // Normalize to array
    if (typeof userRoles === "string") {
      userRoles = [userRoles];
    }

    const hasAccess = allowedRoles.some(role => userRoles.includes(role.toUpperCase()) || userRoles.includes("ROLE_" + role.toUpperCase()));

    if (!hasAccess) {
      return <Navigate to="/login" />;
    }

    return <Outlet />;
  } catch (error) {
    // Invalid token or decode error
    return <Navigate to="/login" />;
  }
};

export default PrivateRoutes;
