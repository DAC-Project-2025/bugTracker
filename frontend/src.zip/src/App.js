import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import ManageTask from "./pages/Admin/ManageTask";
import CreateTask from "./pages/Admin/CreateTask";
import Dashboard from "./pages/Admin/Dashboard";
import ManageUser from "./pages/Admin/ManageUser";
import Login from "./pages/Auth/Login";
import SignUp from "./pages/Auth/SignUp";
import UserDashboard from "./pages/User/UserDashboard";
import MyTasks from "./pages/User/MyTasks";
import ViewTaskDetails from "./pages/User/ViewTaskDetails";
import PrivateRoutes from "./routes/PrivateRoutes";
import KanbanBoard from "./pages/User/KanbanBoard";
import ProjectsPage from "./components/ProjectsPage";
import ProjectDetailsPage from "./components/ProjectDetailsPage";
import AddProjectForm from "./components/AddProjectForm";
import BugDetailsPage from "./components/BugDetailsPage";


function App() {
  localStorage.setItem("token", "eyJhbGciOiJIUzM4NCJ9.eyJpYXQiOjE3NTQ2NDA5NzUsImV4cCI6MTc1NDcyNzM3NSwiZW1haWwiOiJha2F3ZHdhZEBhay5jb20iLCJhdXRob3JpdGllcyI6IlJPTEVfTUFOQUdFUiJ9.rfWsOQdP-dz__2dvoNDd4Na7TeI10Q-CR9Ai41ghBVaa5Sh7c6dBHlM3SPm16Q10");
  return (
    <div>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signUp" element={<SignUp />} />
          {/* <Route path="/kanban/:id" element={<ProjectDetailsPage />} />
          <Route path="/form" element={<AddProjectForm />} />
          <Route path="/bugdetails" element={<BugDetailsPage />} />
          <Route path="/kanban" element={<KanbanBoard />} /> */}
          
          
          {/**Public routes */}

          {/* <Route path="/admin/dashboard" element={<Dashboard />} />
          <Route path="/admin/tasks" element={<ManageTask />} />
          <Route path="/admin/dashboard" element={<Dashboard />} />
          <Route path="/admin/create-task" element={<CreateTask />} />
          <Route path="/admin/users" element={<ManageUser />} /> */}

          {/**Admin routes */}
          <Route  element={<PrivateRoutes allowedRoles={["ADMIN", "MANAGER"]}/>}>
            <Route path="/admin/dashboard" element={<Dashboard />}/>
            <Route path="/admin/tasks" element={<ManageTask />}/>
            <Route path="/admin/dashboard" element={<Dashboard />}/>
            <Route path="/admin/create-task" element={<CreateTask />}/>
            <Route path="/admin/users" element={<ManageUser />}/>
          </Route>

          {/**User routes */}
          <Route element={<PrivateRoutes allowedRoles={["user"]} />}>
            <Route path="/user/dashboard" element={<UserDashboard />} />
            <Route path="/user/tasks" element={<MyTasks />} />
            <Route
              path="/user/task-details/:id"
              element={<ViewTaskDetails />}
            />
            <Route path="/user/create-task" element={<CreateTask />} />
            <Route path="/user/users" element={<ManageUser />} />
          </Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
