import { useState } from 'react';
import { motion } from 'framer-motion';

const ProjectsPage = () => {
  const [activeTab, setActiveTab] = useState('active');
  const [hoveredTab, setHoveredTab] = useState(null);

  // Sample project data
  const projects = {
    active: [
      {
        id: 1,
        title: 'E-commerce Platform',
        description: 'Building a modern online store with payment integration',
        category: 'Web Development',
        progress: 75,
        image: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/02d7c0f1-2021-4fb1-a5e9-3c9c105d6c30.png',
        alt: 'E-commerce website interface on a laptop showing product listings'
      },
      {
        id: 2,
        title: 'Mobile Banking App',
        description: 'Fintech application with biometric authentication',
        category: 'Mobile Development',
        progress: 42,
        image: 'https://placehold.co/600x400',
        alt: 'Smartphone showing banking app interface with transaction history'
      }
    ],
    closed: [
      {
        id: 3,
        title: 'Corporate Website',
        description: 'Company website with CMS integration',
        category: 'Web Development',
        progress: 100,
        image: 'https://placehold.co/600x400',
        alt: 'Corporate website homepage showing the team section'
      }
    ],
    all: [
      {
        id: 1,
        title: 'E-commerce Platform',
        description: 'Building a modern online store with payment integration',
        category: 'Web Development',
        progress: 75,
        alt: 'E-commerce website interface on a laptop showing product listings'
      },
      {
        id: 2,
        title: 'Mobile Banking App',
        description: 'Fintech application with biometric authentication',
        category: 'Mobile Development',
        progress: 42,
        image: 'https://placehold.co/600x400',
        alt: 'Smartphone showing banking app interface with transaction history'
      },
      {
        id: 3,
        title: 'Corporate Website',
        description: 'Company website with CMS integration',
        category: 'Web Development',
        progress: 100,
        image: 'https://placehold.co/600x400',
        alt: 'Corporate website homepage showing the team section'
      }
    ]
  };

  // Tab content with animation variants
  const tabVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -10 }
  };

  // Progress bar colors based on completion percentage
  const getProgressColor = (progress) => {
    if (progress < 30) return 'bg-red-500';
    if (progress < 70) return 'bg-yellow-500';
    if (progress < 90) return 'bg-blue-500';
    return 'bg-green-500';
  };

  // Gradient underline effect for active/hovered tab
  const UnderlineEffect = ({ isActive }) => (
    <motion.div 
      className={`absolute bottom-0 left-0 w-full h-0.5 ${isActive ? 'bg-gradient-to-r from-blue-500 to-purple-600' : ''}`}
      initial={{ scaleX: 0 }}
      animate={{ scaleX: isActive ? 1 : 0 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
    />
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* <div className="text-center mb-12">
          <motion.h1 
            className="text-4xl font-bold text-gray-900 mb-2"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Project Dashboard
          </motion.h1>
          <motion.p 
            className="text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Manage all your active and completed projects in one place
          </motion.p>
        </div> */}

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Tabs Navigation */}
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {['active', 'closed', 'all'].map((tab) => (
                <button
                  key={tab}
                  className={`py-4 px-6 text-center border-b-2 font-medium text-sm relative ${activeTab === tab ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700 border-transparent'}`}
                  onClick={() => setActiveTab(tab)}
                  onMouseEnter={() => setHoveredTab(tab)}
                  onMouseLeave={() => setHoveredTab(null)}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)} Projects
                  {(hoveredTab === tab || activeTab === tab) && (
                    <UnderlineEffect isActive={activeTab === tab} />
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            <motion.div
              key={activeTab}
              initial="hidden"
              animate="visible"
              exit="exit"
              variants={tabVariants}
              transition={{ duration: 0.3 }}
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {projects[activeTab].map((project) => (
                <motion.div
                  key={project.id}
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-shadow duration-300 overflow-hidden"
                >
                  <div className="relative h-40 overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.alt}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.src = 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/6d152ce1-dd08-4de8-b747-370c87456264.png';
                        e.target.alt = 'Placeholder for missing project image';
                      }}
                    />
                    {activeTab === 'active' && (
                      <div className="absolute bottom-0 left-0 right-0 px-4 py-2 bg-black bg-opacity-50 text-white text-sm font-medium">
                        <span>{project.category}</span>
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    
                    {activeTab === 'active' && (
                      <div className="space-y-2">
                        <div className="text-sm text-gray-500 flex justify-between">
                          <span>Progress</span>
                          <span>{project.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className={`h-2.5 rounded-full ${getProgressColor(project.progress)}`} 
                            style={{ width: `${project.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                    {activeTab === 'closed' && (
                      <div className="flex items-center text-green-500">
                        <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="font-medium">Completed</span>
                      </div>
                    )}

                    <div className="mt-4 flex justify-between">
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        View Details
                      </button>
                      <button className="text-gray-500 hover:text-gray-700 text-sm font-medium">
                        {activeTab === 'active' ? 'Track Progress' : 'View Report'}
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {projects[activeTab].length === 0 && (
              <motion.div 
                className="text-center py-12"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5ccb7c45-8e73-4a1e-8593-83c9fb818ac2.png" 
                  alt="No projects found illustration showing an empty folder and a magnifying glass" 
                  className="mx-auto mb-4"
                />
                <h3 className="text-lg font-medium text-gray-900">No {activeTab} projects found</h3>
                <p className="text-gray-500 mt-1">You don't have any {activeTab} projects at the moment</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectsPage;

// ======================================================================================


// import { useState } from 'react';
// import { motion } from 'framer-motion';

// const ProjectsPage = () => {
//   const [activeTab, setActiveTab] = useState('active');
//   const [hoveredTab, setHoveredTab] = useState(null);

//   // Sample project data
//   const projects = {
//     active: [
//       {
//         id: 1,
//         title: 'E-commerce Platform',
//         description: 'Building a modern online store with payment integration',
//         category: 'Web Development',
//         progress: 75
//       },
//       {
//         id: 2,
//         title: 'Mobile Banking App',
//         description: 'Fintech application with biometric authentication',
//         category: 'Mobile Development',
//         progress: 42
//       }
//     ],
//     closed: [
//       {
//         id: 3,
//         title: 'Corporate Website',
//         description: 'Company website with CMS integration',
//         category: 'Web Development',
//         progress: 100
//       }
//     ],
//     all: [
//       {
//         id: 1,
//         title: 'E-commerce Platform',
//         description: 'Building a modern online store with payment integration',
//         category: 'Web Development',
//         progress: 75
//       },
//       {
//         id: 2,
//         title: 'Mobile Banking App',
//         description: 'Fintech application with biometric authentication',
//         category: 'Mobile Development',
//         progress: 42
//       },
//       {
//         id: 3,
//         title: 'Corporate Website',
//         description: 'Company website with CMS integration',
//         category: 'Web Development',
//         progress: 100
//       }
//     ]
//   };

//   // Tab content with animation variants
//   const tabVariants = {
//     hidden: { opacity: 0, y: 10 },
//     visible: { opacity: 1, y: 0 },
//     exit: { opacity: 0, y: -10 }
//   };

//   // Progress bar colors based on completion percentage
//   const getProgressColor = (progress) => {
//     if (progress < 30) return 'bg-red-500';
//     if (progress < 70) return 'bg-yellow-500';
//     if (progress < 90) return 'bg-blue-500';
//     return 'bg-green-500';
//   };

//   // Gradient underline effect for active/hovered tab
//   const UnderlineEffect = ({ isActive }) => (
//     <motion.div 
//       className={`absolute bottom-0 left-0 w-full h-0.5 ${isActive ? 'bg-gradient-to-r from-blue-500 to-purple-600' : ''}`}
//       initial={{ scaleX: 0 }}
//       animate={{ scaleX: isActive ? 1 : 0 }}
//       transition={{ duration: 0.3, ease: 'easeInOut' }}
//     />
//   );

//   return (
//     <div className="min-h-screen bg-gray-50 p-6">
//       <div className="max-w-7xl mx-auto">
//         <div className="text-center mb-12">
//           <motion.h1 
//             className="text-4xl font-bold text-gray-900 mb-2"
//             initial={{ opacity: 0, y: -20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5 }}
//           >
//             Project Dashboard
//           </motion.h1>
//           <motion.p 
//             className="text-gray-600 max-w-2xl mx-auto"
//             initial={{ opacity: 0 }}
//             animate={{ opacity: 1 }}
//             transition={{ duration: 0.5, delay: 0.2 }}
//           >
//             Manage all your active and completed projects in one place
//           </motion.p>
//         </div>

//         <div className="bg-white rounded-xl shadow-lg overflow-hidden">
//           {/* Tabs Navigation */}
//           <div className="border-b border-gray-200">
//             <nav className="flex -mb-px">
//               {['active', 'closed', 'all'].map((tab) => (
//                 <button
//                   key={tab}
//                   className={`py-4 px-6 text-center border-b-2 font-medium text-sm relative ${activeTab === tab ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700 border-transparent'}`}
//                   onClick={() => setActiveTab(tab)}
//                   onMouseEnter={() => setHoveredTab(tab)}
//                   onMouseLeave={() => setHoveredTab(null)}
//                 >
//                   {tab.charAt(0).toUpperCase() + tab.slice(1)} Projects
//                   {(hoveredTab === tab || activeTab === tab) && (
//                     <UnderlineEffect isActive={activeTab === tab} />
//                   )}
//                 </button>
//               ))}
//             </nav>
//           </div>

//           {/* Tab Content */}
//           <div className="p-6">
//             <motion.div
//               key={activeTab}
//               initial="hidden"
//               animate="visible"
//               exit="exit"
//               variants={tabVariants}
//               transition={{ duration: 0.3 }}
//               className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
//             >
//               {projects[activeTab].map((project) => (
//                 <motion.div
//                   key={project.id}
//                   whileHover={{ y: -5 }}
//                   className="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-shadow duration-300 overflow-hidden"
//                 >
//                   <div className="p-5">
//                     {activeTab === 'active' && (
//                       <div className="mb-3 px-3 py-1 bg-gray-100 text-gray-800 text-sm font-medium rounded-full inline-block">
//                         {project.category}
//                       </div>
//                     )}
                    
//                     <h3 className="text-xl font-bold text-gray-900 mb-2">{project.title}</h3>
//                     <p className="text-gray-600 mb-4">{project.description}</p>
                    
//                     {activeTab === 'active' && (
//                       <div className="space-y-2">
//                         <div className="text-sm text-gray-500 flex justify-between">
//                           <span>Progress</span>
//                           <span>{project.progress}%</span>
//                         </div>
//                         <div className="w-full bg-gray-200 rounded-full h-2.5">
//                           <div 
//                             className={`h-2.5 rounded-full ${getProgressColor(project.progress)}`} 
//                             style={{ width: `${project.progress}%` }}
//                           ></div>
//                         </div>
//                       </div>
//                     )}

//                     {activeTab === 'closed' && (
//                       <div className="flex items-center text-green-500">
//                         <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
//                         </svg>
//                         <span className="font-medium">Completed</span>
//                       </div>
//                     )}

//                     <div className="mt-4 flex justify-between">
//                       <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
//                         View Details
//                       </button>
//                       <button className="text-gray-500 hover:text-gray-700 text-sm font-medium">
//                         {activeTab === 'active' ? 'Track Progress' : 'View Report'}
//                       </button>
//                     </div>
//                   </div>
//                 </motion.div>
//               ))}
//             </motion.div>

//             {projects[activeTab].length === 0 && (
//               <motion.div 
//                 className="text-center py-12"
//                 initial={{ opacity: 0 }}
//                 animate={{ opacity: 1 }}
//                 transition={{ delay: 0.3 }}
//               >
//                 <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
//                   <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
//                   </svg>
//                 </div>
//                 <h3 className="text-lg font-medium text-gray-900">No {activeTab} projects found</h3>
//                 <p className="text-gray-500 mt-1">You don't have any {activeTab} projects at the moment</p>
//               </motion.div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ProjectsPage;
