import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

const BugDetailsPage = () => {
  const [bug, setBug] = useState({
    id: 'BUG-1024',
    title: 'Login page crashes on Safari browsers',
    description: 'When users attempt to login using Safari, the page crashes with a white screen. This happens on both desktop and mobile versions of Safari.',
    status: 'open',
    priority: 'high',
    created: '2023-04-15T14:32:00',
    reporter: { name: 'Alice Johnson', avatar: 'AJ' },
    assignee: { name: 'David Chen', avatar: 'DC', online: true },
    environment: 'Production',
    browser: 'Safari 16.4',
    os: 'iOS 16/macOS Ventura',
    attachments: [
      { id: 1, name: 'screenshot-crash.png', size: '2.4 MB', type: 'image', url: '#' },
      { id: 2, name: 'console-errors.log', size: '158 KB', type: 'text', url: '#' }
    ]
  });

  const [comments, setComments] = useState([
    {
      id: 1,
      author: { name: 'David Chen', avatar: 'DC', online: true },
      content: [
        "I've reproduced the issue. It seems to be related to the authentication library we're using.",
        <span key="code" className="bg-gray-100 font-mono text-sm p-1 rounded">AuthProvider.js: line 42</span>
      ],
      timestamp: '2023-04-15T15:45:00',
      reactions: [{ emoji: '👍', count: 2 }, { emoji: '❓', count: 1 }]
    },
    {
      id: 2,
      author: { name: 'You', avatar: 'YO', online: true },
      content: "Thanks for checking. Any idea when we can expect a fix? The client is asking for an ETA.",
      timestamp: '2023-04-15T16:20:00',
      reactions: []
    }
  ]);

  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Floating action menu state
  const [actionMenuOpen, setActionMenuOpen] = useState(false);

  // UI Helpers
  const getPriorityColor = () => {
    const colors = {
      high: 'from-red-500 to-pink-600',
      medium: 'from-amber-500 to-orange-600',
      low: 'from-green-500 to-emerald-600',
      critical: 'from-purple-600 to-red-600'
    };
    return colors[bug.priority] || 'from-gray-500 to-gray-600';
  };

  const getStatusColor = () => {
    const colors = {
      open: 'bg-blue-100 text-blue-800',
      'in-progress': 'bg-purple-100 text-purple-800',
      resolved: 'bg-teal-100 text-teal-800',
      closed: 'bg-gray-100 text-gray-800'
    };
    return colors[bug.status] || 'bg-gray-100 text-gray-800';
  };

  const getFileIcon = (type) => {
    const icons = {
      image: '🖼️',
      text: '📄',
      pdf: '📝',
      zip: '🗄️'
    };
    return icons[type] || '📁';
  };

  // Handlers
  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setComments([...comments, {
      id: comments.length + 1,
      author: { name: 'You', avatar: 'YO', online: true },
      content: newComment,
      timestamp: new Date().toISOString(),
      reactions: []
    }]);
    
    setNewComment('');
    setIsSubmitting(false);
  };

  const addReaction = (commentId, emoji) => {
    setComments(comments.map(comment => {
      if (comment.id !== commentId) return comment;
      
      const existingReaction = comment.reactions.find(r => r.emoji === emoji);
      if (existingReaction) {
        return {
          ...comment,
          reactions: comment.reactions.map(r => 
            r.emoji === emoji ? { ...r, count: r.count + 1 } : r
          )
        };
      }
      
      return {
        ...comment,
        reactions: [...comment.reactions, { emoji, count: 1 }]
      };
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      {/* <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r bg-clip-text text-transparent from-blue-600 to-purple-600">
            Bug Tracker
          </h1>
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-gray-100 transition-all">
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
            </button>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-medium">
              YO
            </div>
          </div>
        </div>
      </header> */}

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main Content */}
          <div className="flex-1 space-y-6">
            {/* Bug Header */}
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="bg-white rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center space-x-3">
                      <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${getStatusColor()}`}>
                        {bug.status.replace('-', ' ')}
                      </span>
                      <span className={`text-xs font-medium bg-gradient-to-r ${getPriorityColor()} text-white px-2.5 py-0.5 rounded-full`}>
                        {bug.priority} priority
                      </span>
                    </div>
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mt-3">{bug.title}</h1>
                  </div>
                  
                  {/* Floating action button */}
                  <div className="relative">
                    <button 
                      onClick={() => setActionMenuOpen(!actionMenuOpen)}
                      className="w2 h2 p-2 rounded-full bg-gradient-to-r bg-gray-300 text-black  shadow-lg hover:shadow-xl transition-all"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                    
                    <AnimatePresence>
                      {actionMenuOpen && (
                        <motion.div 
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 20 }}
                          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                          className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-10"
                        >
                          <div className="py-1">
                            <button className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                              Edit Bug
                            </button>
                            <button className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                              Change Status
                            </button>
                            <button className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                              Delete Bug
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
                
                <div className="mt-4">
                  <div className="prose prose-sm max-w-none text-gray-600">
                    <p className="text-gray-800 font-medium">Description</p>
                    <p>{bug.description}</p>
                  </div>
                </div>
                
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Reporter</p>
                    <div className="flex items-center mt-1">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-medium mr-2">
                        {bug.reporter.avatar}
                      </div>
                      <span className="font-medium text-gray-900">{bug.reporter.name}</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Assignee</p>
                    <div className="flex items-center mt-1">
                      <div className="relative">
                        <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 font-medium mr-2">
                          {bug.assignee.avatar}
                        </div>
                        <span className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full ${bug.assignee.online ? 'bg-green-500' : 'bg-gray-300'} border-2 border-white`}></span>
                      </div>
                      <span className="font-medium text-gray-900">{bug.assignee.name}</span>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Environment</p>
                    <p className="mt-1 font-medium">{bug.environment}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Browser</p>
                    <p className="mt-1 font-medium">{bug.browser}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">OS</p>
                    <p className="mt-1 font-medium">{bug.os}</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Attachments */}
            {bug.attachments.length > 0 && (
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="bg-white rounded-2xl shadow-xl overflow-hidden"
              >
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    Attachments
                    <span className="ml-2 bg-gray-100 text-gray-800 text-xs font-medium px-2 py-0.5 rounded-full">
                      {bug.attachments.length}
                    </span>
                  </h2>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {bug.attachments.map((file) => (
                      <motion.div 
                        key={file.id}
                        whileHover={{ y: -2 }}
                        className="border border-gray-100 rounded-lg p-3 hover:shadow-md transition-all cursor-pointer"
                      >
                        <div className="flex items-start space-x-3">
                          <div className="bg-blue-50 p-2 rounded-lg text-2xl">
                            {getFileIcon(file.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
                            <p className="text-xs text-gray-500 mt-0.5">{file.size}</p>
                            <button 
                              className="mt-2 text-xs font-medium text-blue-600 hover:text-blue-800 transition"
                              onClick={(e) => {
                                e.stopPropagation();
                                // Download logic here
                              }}
                            >
                              Download
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Comments */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Comments</h2>
                
                <div className="space-y-6">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex items-start space-x-3 group">
                      <div className="relative flex-shrink-0">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center text-purple-800 font-medium">
                          {comment.author.avatar}
                        </div>
                        {comment.author.online && (
                          <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-green-500 border-2 border-white"></span>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="bg-gray-50 rounded-2xl p-4">
                          <div className="flex justify-between items-baseline">
                            <span className="font-medium text-gray-900">{comment.author.name}</span>
                            <span className="text-xs text-gray-500">
                              {formatDistanceToNow(new Date(comment.timestamp), { addSuffix: true })}
                            </span>
                          </div>
                          
                          <div className="mt-1.5 text-gray-700">
                            {Array.isArray(comment.content) 
                              ? comment.content.map((c, i) => <div key={i}>{c}</div>)
                              : comment.content
                            }
                          </div>
                          
                          {comment.reactions.length > 0 && (
                            <div className="mt-2 flex space-x-2">
                              {comment.reactions.map((reaction) => (
                                <motion.button
                                  key={reaction.emoji}
                                  whileTap={{ scale: 1.2 }}
                                  className="text-xs bg-gray-100 px-2 py-0.5 rounded-full hover:bg-gray-200 transition"
                                  onClick={() => addReaction(comment.id, reaction.emoji)}
                                >
                                  {reaction.emoji} {reaction.count}
                                </motion.button>
                              ))}
                            </div>
                          )}
                        </div>
                        
                        <div className="mt-1.5 flex space-x-4 opacity-0 group-hover:opacity-100 transition">
                          <button className="text-xs text-gray-500 hover:text-gray-700">Reply</button>
                          <button className="text-xs text-gray-500 hover:text-gray-700">Edit</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Add Comment */}
                <form onSubmit={handleCommentSubmit} className="mt-6">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-medium flex-shrink-0">
                      YO
                    </div>
                    
                    <div className="flex-1 relative">
                      <textarea
                        rows={3}
                        className="block w-full border-gray-300 shadow-sm rounded-xl bg-gray-50 focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                        placeholder="Add a comment..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                      />
                      
                      <div className="absolute right-3 bottom-3 flex space-x-2">
                        <button
                          type="button"
                          className="p-1.5 rounded-lg hover:bg-gray-200 transition text-gray-500"
                          title="Add emoji"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </button>
                        
                        <button
                          type="button"
                          className="p-1.5 rounded-lg hover:bg-gray-200 transition text-gray-500"
                          title="Attach file"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                          </svg>
                        </button>
                      </div>
                      
                      <div className="mt-3 flex justify-end">
                        <motion.button
                          type="submit"
                          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium rounded-lg shadow hover:shadow-md transition-all disabled:opacity-70"
                          disabled={!newComment.trim() || isSubmitting}
                          whileTap={{ scale: 0.98 }}
                        >
                          {isSubmitting ? 'Posting...' : 'Post Comment'}
                        </motion.button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:w-80 space-y-6">
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Details</h2>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Created</p>
                    <p className="mt-1 font-medium">
                      {formatDistanceToNow(new Date(bug.created), { addSuffix: true })}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Status</p>
                    <select
                      className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50 py-2 px-3"
                      value={bug.status}
                      onChange={(e) => setBug({...bug, status: e.target.value})}
                    >
                      <option value="open">Open</option>
                      <option value="in-progress">In Progress</option>
                      <option value="resolved">Resolved</option>
                      <option value="closed">Closed</option>
                    </select>
                  </div>
                  
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</p>
                    <select
                      className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50 py-2 px-3"
                      value={bug.priority}
                      onChange={(e) => setBug({...bug, priority: e.target.value})}
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                      <option value="critical">Critical</option>
                    </select>
                  </div>
                  
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Assign To</p>
                    <div className="mt-1">
                      <div className="relative">
                        <select
                          className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50 py-2 px-3"
                          value={bug.assignee.name}
                          onChange={(e) => setBug({
                            ...bug, 
                            assignee: { 
                              ...bug.assignee, 
                              name: e.target.value,
                              // In a real app, update avatar too
                            }
                          })}
                        >
                          <option>Unassigned</option>
                          <option>David Chen</option>
                          <option>Alice Johnson</option>
                          <option>Sam Wilson</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Activity</h2>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="relative flex-shrink-0 mr-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-800 text-sm font-medium">
                        AJ
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm">
                        <span className="font-medium text-gray-900">Alice Johnson</span> reported this bug
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {formatDistanceToNow(new Date(bug.created), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="relative flex-shrink-0 mr-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-100 text-purple-800 text-sm font-medium">
                        DC
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm">
                        <span className="font-medium text-gray-900">David Chen</span> assigned to bug
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        1 hour ago
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="relative flex-shrink-0 mr-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 text-gray-800 text-sm font-medium">
                        S
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm">
                        Status changed from <span className="font-medium">Open</span> to <span className="font-medium">In Progress</span>
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        45 minutes ago
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default BugDetailsPage;
