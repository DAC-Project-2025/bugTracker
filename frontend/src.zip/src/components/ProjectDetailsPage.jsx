import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const ProjectDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Sample project data - in a real app, you'd fetch this from an API
  useEffect(() => {
    // Simulate API fetch
    const projects = [
      {
        id: 1,
        title: 'E-commerce Platform',
        description: 'Building a modern online store with payment integration',
        longDescription: 'Complete redesign and development of an e-commerce platform with modern UI/UX, secure payment processing, inventory management, and admin dashboard.',
        category: 'Web Development',
        status: 'active',
        progress: 75,
        startDate: '2023-01-15',
        deadline: '2023-06-30',
        team: ['Sarah Johnson', 'Michael Chen', 'Lisa Wong'],
        technologies: ['React', 'Node.js', 'MongoDB', 'Stripe API'],
        milestones: [
          { name: 'Requirements Complete', completed: true, date: '2023-02-01' },
          { name: 'UI/UX Approved', completed: true, date: '2023-03-15' },
          { name: 'Backend API Complete', completed: false },
          { name: 'Security Audits', completed: false },
          { name: 'Launch', completed: false }
        ]
      },
      {
        id: 2,
        title: 'Mobile Banking App',
        description: 'Fintech application with biometric authentication',
        longDescription: 'Development of a cross-platform mobile banking application with biometric login, transaction history, bill pay, and fraud detection features.',
        category: 'Mobile Development',
        status: 'active',
        progress: 42,
        startDate: '2023-03-01',
        deadline: '2023-09-15',
        team: ['Alex Gomez', 'Priya Patel', 'David Kim'],
        technologies: ['React Native', 'Firebase', 'Plaid API'],
        milestones: [
          { name: 'Prototype Approved', completed: true, date: '2023-03-25' },
          { name: 'Auth System Complete', completed: true, date: '2023-04-10' },
          { name: 'Transaction History', completed: false },
          { name: 'Payment System', completed: false },
          { name: 'Security Review', completed: false },
          { name: 'Beta Launch', completed: false }
        ]
      },
      {
        id: 3,
        title: 'Corporate Website',
        description: 'Company website with CMS integration',
        longDescription: 'Development of responsive corporate website with CMS integration for marketing team to easily update content without developer intervention.',
        category: 'Web Development',
        status: 'closed',
        progress: 100,
        startDate: '2022-11-01',
        deadline: '2022-12-15',
        completedDate: '2022-12-10',
        team: ['Emma Davis', 'Ryan Wilson'],
        technologies: ['Next.js', 'Contentful CMS', 'Tailwind CSS'],
        milestones: [
          { name: 'Design Approved', completed: true, date: '2022-11-15' },
          { name: 'CMS Integration', completed: true, date: '2022-11-30' },
          { name: 'Staff Training', completed: true, date: '2022-12-05' },
          { name: 'Official Launch', completed: true, date: '2022-12-10' }
        ]
      }
    ];

    const foundProject = projects.find(p => p.id === parseInt(id));
    
    setTimeout(() => {
      if (foundProject) {
        setProject(foundProject);
      }
      setLoading(false);
    }, 500);
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Project Not Found</h2>
          <button 
            onClick={() => navigate(-1)}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
          >
            Back to Projects
          </button>
        </div>
      </div>
    );
  }

  const getStatusBadge = () => {
    switch(project.status) {
      case 'active':
        return (
          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
            In Progress
          </span>
        );
      case 'closed':
        return (
          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
            Completed
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
            Planning
          </span>
        );
    }
  };

  const getProgressColor = (progress) => {
    if (progress < 30) return 'bg-red-500';
    if (progress < 70) return 'bg-yellow-500';
    if (progress < 90) return 'bg-blue-500';
    return 'bg-green-500';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex justify-between items-start">
              <div>
                <button 
                  onClick={() => navigate(-1)}
                  className="flex items-center text-gray-600 hover:text-gray-900 mb-4 transition"
                >
                  <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                  </svg>
                  Back to Projects
                </button>
                
                <h1 className="text-3xl font-bold text-gray-900">{project.title}</h1>
                <p className="text-lg text-gray-600 mt-1">{project.description}</p>
              </div>
              
              <div className="flex items-center space-x-4">
                {getStatusBadge()}
                <div className="text-sm text-gray-500">
                  {project.status === 'closed' ? (
                    <span>Completed on {project.completedDate}</span>
                  ) : (
                    <span>Due on {project.deadline}</span>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Project Overview */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="bg-white shadow rounded-lg p-6 mb-8"
            >
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Project Overview</h2>
              <p className="text-gray-600 mb-6">{project.longDescription}</p>
              
              {project.status === 'active' && (
                <div className="space-y-4">
                  <div className="text-sm text-gray-500 flex justify-between">
                    <span>Progress</span>
                    <span>{project.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${getProgressColor(project.progress)}`}
                      style={{ width: `${project.progress}%` }}
                    ></div>
                  </div>
                  <div className="text-sm text-gray-500 flex justify-between">
                    <span>Started: {project.startDate}</span>
                    <span>Deadline: {project.deadline}</span>
                  </div>
                </div>
              )}
            </motion.div>

            {/* Milestones */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.2 }}
              className="bg-white shadow rounded-lg p-6 mb-8"
            >
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Milestones</h2>
              <div className="space-y-4">
                {project.milestones.map((milestone, index) => (
                  <div key={index} className="flex items-start">
                    <div className={`flex-shrink-0 h-5 w-5 rounded-full flex items-center justify-center mt-1 mr-3 ${milestone.completed ? 'bg-green-500' : 'bg-gray-200'}`}>
                      {milestone.completed && (
                        <svg className="h-3 w-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                      )}
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between">
                        <h3 className={`text-gray-800 ${milestone.completed ? 'font-medium' : ''}`}>{milestone.name}</h3>
                        {milestone.completed && (
                          <span className="text-sm text-gray-500">{milestone.date}</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div>
            {/* Team Members */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.3 }}
              className="bg-white shadow rounded-lg p-6 mb-8"
            >
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Team Members</h2>
              <div className="space-y-3">
                {project.team.map((member, index) => (
                  <div key={index} className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium mr-3">
                      {member.charAt(0)}
                    </div>
                    <div>
                      <p className="text-gray-800 font-medium">{member}</p>
                      <p className="text-sm text-gray-500">{project.team.length > 3 && index === 0 ? 'Project Lead' : 'Team Member'}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Technologies */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.4 }}
              className="bg-white shadow rounded-lg p-6 mb-8"
            >
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Technologies</h2>
              <div className="flex flex-wrap gap-2">
                {project.technologies.map((tech, index) => (
                  <span key={index} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    {tech}
                  </span>
                ))}
              </div>
            </motion.div>

            {/* Actions */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.5 }}
              className="bg-white shadow rounded-lg p-6"
            >
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Project Actions</h2>
              <div className="space-y-3">
                <button className="w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
                  {project.status === 'active' ? 'Update Progress' : 'View Final Report'}
                </button>
                <button className="w-full px-4 py-2 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition">
                  Share Project
                </button>
                {project.status === 'active' && (
                  <button className="w-full px-4 py-2 text-blue-600 hover:text-blue-800 transition">
                    Request Deadline Extension
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetailsPage;
